import configure as config
import utils
import pickle
import scipy.io

# data processing
model_name = "MITOR_V2_trained_wo_mlp_4_5_22.obj"
model_location = '../saved_model/'+model_name
data = scipy.io.loadmat(config.data_location) # data format: dict
[X_train, Y_train, X_test, Y_test, adj_data] = utils.data_formulate(data)
model_load_file = open(model_location, 'rb')
MITOR_V2_trained = pickle.load(model_load_file)
[mze, mae, Y_pred] = MITOR_V2_trained.predict(X_test, Y_test, True)
print("On Test Data: Mean Zero-one Error = {}, Mean Absolute Error = {}".format(mze, mae))