import configure as config
import model
# Reading Data
import scipy.io
import numpy as np
from sklearn.model_selection import train_test_split
import torch
import pickle
import proximal_gradient.proximalGradient as pg


data = scipy.io.loadmat('../data/MITOR_Data.mat') # data format: dict
x_data = data['X'] # shape (26,550,1289) (Task ID (Spatial location), Sample (Temporal-Days), Features(TF-IDF)) # Civil Unrest Data
y_data = data['Y'] # shape (26, 550)
adj_data = data['adj'] # shape (26, 26)

y_data_3d = np.expand_dims(y_data, axis=2)
data_concat = np.swapaxes(np.concatenate((x_data, y_data_3d),axis = 2),0,1)
data_train, data_test = train_test_split(data_concat, test_size=0.5, random_state=42, shuffle=True)  # Split the set

X_train = torch.swapaxes(torch.FloatTensor(data_train[:,:,0:-1]), 0, 1) # Shape([26, 275, 1289])
Y_train = torch.swapaxes(torch.FloatTensor(data_train[:,:,-1]), 0, 1)
X_test = torch.swapaxes(torch.FloatTensor(data_test[:,:,0:-1]), 0, 1)
Y_test = torch.swapaxes(torch.FloatTensor(data_test[:,:,-1]), 0, 1)

# Configure
input_dim = 1289
hidden_dim = 200
lr=0.08 # default: 0.8 # play with this
# L2,1 norm co-effecient (can be chose using validation set)
alpha=0 # default:0
# threshold theta constriants co-efficient (can be chose using validation set)
beta=0.01 # default: 0.01

values = Y_train.unique()
k = values.shape[0]
TRAIN_size = Y_train.shape[1]
TASK_num = Y_train.shape[0]
BIG = float('inf')
SMALL = float('-inf')
d = input_dim
R = torch.zeros((TASK_num, TASK_num))
for i in range(TASK_num):
    nb = sum(adj_data[:, i] == 1) # bug fixed coverting 1 to i
    if nb > 0:
        R[:, i] = -torch.from_numpy(adj_data[:, i] / nb) # bug fixed coverting 1 to i
        R[i, i] = 1
L = torch.matmul(R, np.transpose(R))
E = torch.eye((TASK_num))
W_mat = scipy.io.loadmat(config.train_weight_location)
W = torch.tensor(W_mat['W']).float()
U = W
Y1 = torch.zeros(W.shape)
# initialize threshold size : (k-1)*TASK_num
pi = torch.nn.Parameter(torch.ones(k - 1, 1) * 1 / k)
cum_pi = torch.cumsum(pi, dim=0)
T = torch.log(cum_pi / (1 - cum_pi))
T = T.repeat(1, TASK_num)
Y2 = torch.zeros(T.shape)
V = T
Y3 = torch.zeros(k - 2, T.shape[1])
# initialize learning rate lambda
lambda_w = lr
lambda_t = lr
# admm param
rho = 1
# set max number of iterations for GD on W,T  update (can be shorter if meet stop critira)
Max_iteration = 1
f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
f2inv = torch.linalg.inv(beta * L + rho * E)
adi = 0
L_old = float('inf') # Previous loss
I = torch.zeros(Max_iteration)
L_train = torch.zeros(Max_iteration)
t=0
loss = 0
GW = torch.zeros((d, TASK_num))
GT = torch.zeros((k - 1, TASK_num))
i=0
j=0
X_hidden = X_train[i,j,:]
sig1= 1 / (1 + torch.exp(-(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))))
# sig1 = 1 / (1 + torch.exp(-(T[int(Y_train[i, j]) - 1, i] + torch.matmul(X_hidden, W[:, i])))) # Bug warning: according to eq1 it may be +
sig2=0
dif=SMALL
l_cum=-torch.log(sig1-sig2)
loss=loss+l_cum
gradient_w = X_hidden*(1-sig1-sig2)
GW[:,i]=GW[:,i]+gradient_w
gradient_t=torch.zeros(k-1)
gradient_t[int(Y_train[i,j])-1]=sig1-1
GT[:,i]=GT[:,i]+gradient_t
GW = 1 / TRAIN_size * 1 / TASK_num * GW + Y1 + rho * (W - U)
GT = 1 / TRAIN_size * 1 / TASK_num * GT + Y2 + rho * (T - V)
# update parameters
W = W - lambda_w * GW
T = T - lambda_t * GT
I[t] = t
L_train[t] = 1 / TRAIN_size * 1 / TASK_num * loss + torch.sum(torch.sum(torch.matmul(Y1, torch.transpose((W - U), 0, 1)))) + (rho / 2.) * torch.sum(
                torch.sum(torch.square((W - U)))) + torch.sum(torch.sum(torch.matmul(Y2,  torch.transpose((T - V), 0, 1)))) + (rho / 2) * torch.sum(
                torch.sum(torch.square(T - V))) # bug fixed by using matmul and transpose

L_old = L_train[t]
U_old = U
U = W + 1 / rho * Y1
pg.l21(U, reg=alpha / rho)
V_old = V
V[0, :] = 1 / rho * Y2[0, :] + T[0, :] # bug fixed converting 1 to 0
for i in range(1, k - 1):  # Not sure about the range starting point
    f1 = torch.matmul(
        (torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * (T[i, :] + V[i - 1, :]) + Y3[i - 1, :]), f1inv)
    f2 = torch.matmul((torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * T[i, :] + Y3[i - 1, :]), f2inv)
    V[i, f1 <= V[i - 1, :]] = f1[f1 <= V[i - 1, :]]
    V[i, f2 > V[i - 1, :]] = f2[f2 > V[i - 1, :]]
Y1 = Y1 + rho * (W - U)
Y2 = Y2 + rho * (T - V)
for i in range(1, k - 1):
    Y3[i - 1, :] = torch.maximum(Y3[i - 1, :] + rho * (V[i - 1, :] - V[i, :]), torch.zeros(TASK_num))
s = rho * torch.sqrt(torch.sum(torch.sum(torch.square(U_old - U)))) + rho * torch.sqrt(
        torch.sum(torch.sum(torch.square(V_old - V)))) # bug warning: 1/10 smaller than matlab output
r = torch.sqrt(torch.sum(torch.sum(torch.square(U - W)))) + torch.sqrt(torch.sum(torch.sum(torch.square(V - T))))
if (r > 10 * s): # bug warning: Maybe 10 is very big. Most of the time this condision is not triggered
    rho = 2 * rho
    #   update inverse matrix for computation of V-update when rho changes
    f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
    f2inv = torch.linalg.inv(beta * L + rho * E)
else:
    if (10  * r < s): # bug warning: Maybe 10 is very big. Most of the time this condision is not triggered
        rho = rho / 2
        #       update inverse matrix for computation of V-update when rho changes
        f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
        f2inv = torch.linalg.inv(beta * L + rho * E)
T = T
W = -W