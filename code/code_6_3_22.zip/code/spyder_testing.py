# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#%%
# import libraries
import scipy.io
import numpy as np
from sklearn.model_selection import train_test_split
import torch
import pickle
import torch
import numpy as np
import torch.nn.functional as F
import proximal_gradient.proximalGradient as pg
from sklearn import metrics
import pandas as pd
import time
#%%
# Data Pre-Processing
data = scipy.io.loadmat('../data/flu_datasets/2011-2012_flu_normalized.mat') # data format: dict
x_data = data['X'] # shape (26,550,1289) (Task ID (Spatial location), Sample (Temporal-Days), Features(TF-IDF)) # Civil Unrest Data
y_data = data['Y'] # shape (26, 550)
adj_data = data['adj'] # shape (26, 26)

y_data_3d = np.expand_dims(y_data, axis=2)
data_concat = np.swapaxes(np.concatenate((x_data, y_data_3d),axis = 2),0,1)
data_train, data_test = train_test_split(data_concat, test_size=0.5, random_state=42, shuffle=True)  # Split the set

X_train = torch.swapaxes(torch.FloatTensor(data_train[:,:,0:-1]), 0, 1) # Shape([26, 275, 1289])
Y_train = torch.swapaxes(torch.FloatTensor(data_train[:,:,-1]), 0, 1)
X_test = torch.swapaxes(torch.FloatTensor(data_test[:,:,0:-1]), 0, 1)
Y_test = torch.swapaxes(torch.FloatTensor(data_test[:,:,-1]), 0, 1)
#%%
# Configuration
model_location = '../saved_model/MITOR_V2_trained.obj'
training_progress_log = '../saved_model/training_progress_using_raw_features.csv'
using_mlp = False
input_dim = 1289
hidden_dim = 10
# Parameters
# learning rate for gradient descent
lr=0.8
# L2,1 norm co-effecient (can be chose using validation set)
alpha=0
# threshold theta constriants co-efficient (can be chose using validation set)
beta=0.01
# set max number of iterations for GD on W,T  update (can be shorter if meet stop critira)
adi_range = 1 #500
max_iteration= 1 #1000
#%%
# Model Initialization
fc1 = torch.nn.Linear(input_dim, hidden_dim)
logsig = torch.nn.LogSigmoid()

#%%
# fit function
#  def fit(self, X_train,Y_train,adj_data,lr,alpha,beta, pred_too=True):

adi_list = []
adi_time_list = []
r_list = []
s_list = []
rho_list = []
mze_list = []
mae_list = []
#%%
values = Y_train.unique()
k = values.shape[0]
TRAIN_size = Y_train.shape[1]
TASK_num = Y_train.shape[0]
BIG = float('inf')
SMALL = float('-inf')
# d=demension of feature vector
if using_mlp:
    d = hidden_dim
else:
    d = input_dim

R = torch.zeros((TASK_num, TASK_num))
for i in range(TASK_num):
  nb = sum(adj_data[:, i] == 1)
  if nb > 0:
    R[:, i] = -torch.from_numpy(adj_data[:, i] / nb)
    R[i, i] = 1

#%%
L = torch.matmul(R, np.transpose(R))
E = torch.eye((TASK_num))
# initialize parameters for training data for each task(size= d*TASK_num)
W = torch.nn.Parameter(torch.empty(d, TASK_num).normal_(mean=0, std=0.1)) # Different than Matlab as it is randomization
U = W
Y1 = torch.zeros(W.shape)
# initialize threshold size : (k-1)*TASK_num
pi = torch.nn.Parameter(torch.ones(k - 1, 1) * 1 / k)
# assign each class with same probability
cum_pi = torch.cumsum(pi, dim=0)  # Need to check here
T = torch.log(cum_pi / (1 - cum_pi))
T = T.repeat(1, TASK_num)
Y2 = torch.zeros(T.shape)
V = T
Y3 = torch.zeros(k - 2, T.shape[1])
# initialize learning rate lambda
lambda_w = lr
lambda_t = lr
# admm param
rho = 1

# set max number of iterations for GD on W,T  update (can be shorter if meet stop critira)
Max_iteration = max_iteration
f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
f2inv = torch.linalg.inv(beta * L + rho * E)
#%%
# outer loop (W{Mitor W+h(x)}, U, V, Y, )
adi = 1

adi_tic = time.perf_counter()
L_old = float('inf') # Previous loss
I = torch.zeros(Max_iteration)
L_train = torch.zeros(Max_iteration)
#%%
  # Update W,T via gradient decent
#  for t in range(Max_iteration):
    # cross tasks overall loss
t=0
loss = 0
GW = torch.zeros((d, TASK_num))
GT = torch.zeros((k - 1, TASK_num))
i = 1
j = 1
#for i in range(TASK_num):
#        for j in range(TRAIN_size):
            # calculate what is the model predict is
if using_mlp:
    X_hidden = F.relu(fc1(X_train[i,j,:]))
else:
    X_hidden = X_train[i,j,:]
if Y_train[i,j]==k:
    sig1=1
    # sig2= self.logsig(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))
    sig2= 1 / (1 + torch.exp(-(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))))
    dif=SMALL
elif Y_train[i,j]==1:
    # sig1= self.logsig(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))
    sig1= 1 / (1 + torch.exp(-(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))))
    sig2=0
    dif=SMALL
else:
    # sig1= self.logsig(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))
    sig1= 1 / (1 + torch.exp(-(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))))
    # sig2= self.logsig(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))
    sig2= 1 / (1 + torch.exp(-(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))))
    dif= T[int(Y_train[i,j])-2,i]-T[int(Y_train[i,j])-1,i]

#%%
# loss
l_cum=-torch.log(sig1-sig2)

if(l_cum==float('inf')):
    print("error: inf loss, please decrease learning rate!")
loss=loss+l_cum
if using_mlp:
    l_cum.backward(retain_graph=True)
else:
    pass
# we want to minimize p_cum w.r.t W and T
# Gradient Decent
gradient_w = X_hidden*(1-sig1-sig2)
GW[:,i]=GW[:,i]+gradient_w
gradient_t=torch.zeros(k-1)
# Form canonical vector e_yi and e_yi-1
if Y_train[i,j]==k:
    gradient_t[int(Y_train[i,j])-2]=sig2
elif Y_train[i,j]==1:
    gradient_t[int(Y_train[i,j])-1]=sig1-1
else:
    gradient_t[int(Y_train[i,j])-1]=sig1-1+1/(1-torch.exp(-dif))
    gradient_t[int(Y_train[i,j])-2]=sig2-1+1/(1-torch.exp(dif))
GT[:,i]=GT[:,i]+gradient_t

GW = 1 / TRAIN_size * 1 / TASK_num * GW + Y1 + rho * (W - U)
GT = 1 / TRAIN_size * 1 / TASK_num * GT + Y2 + rho * (T - V)
# update parameters
W = W - lambda_w * GW
T = T - lambda_t * GT
I[t] = t
L_train[t] = 1 / TRAIN_size * 1 / TASK_num * loss + torch.sum(torch.sum(Y1 * (W - U))) + (rho / 2.) * torch.sum(
  torch.sum(torch.square((W - U)))) + torch.sum(torch.sum(Y2 * (T - V))) + (rho / 2) * torch.sum(
  torch.sum(torch.square(T - V)))
L_train[t] = 1 / TRAIN_size * 1 / TASK_num * loss + torch.sum(torch.sum(torch.matmul(Y1, torch.transpose((W - U), 0, 1)))) + (rho / 2.) * torch.sum(
          torch.sum(torch.square((W - U)))) + torch.sum(torch.sum(torch.matmul(Y2,  torch.transpose((T - V), 0, 1)))) + (rho / 2) * torch.sum(
          torch.sum(torch.square(T - V)))
if L_old-L_train[t]<1e-2:
    break
L_old = L_train[t]

  # Update U
  U_old = U
  U = W + 1 / rho * Y1
  U1 = W + 1 / rho * Y1
  pg.l21(U, reg=alpha / rho)

#%%
  
  # Update V
  V_old = V
  V[0, :] = 1 / rho * Y2[0, :] + T[0, :]
  for i in range(1, k - 1):  # Not sure about the range starting point
    f1 = torch.matmul(
      (torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * (T[i, :] + V[i - 1, :]) + Y3[i - 1, :]), f1inv)
    f2 = torch.matmul((torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * T[i, :] + Y3[i - 1, :]), f2inv)
    V[i, f1 <= V[i - 1, :]] = f1[f1 <= V[i - 1, :]]
    V[i, f2 > V[i - 1, :]] = f2[f2 > V[i - 1, :]]
  # Update Y
  Y1 = Y1 + rho * (W - U)
  Y2 = Y2 + rho * (T - V)
  for i in range(1, k - 1):  # Not sure about the range starting point
    Y3[i - 1, :] = torch.maximum(Y3[i - 1, :] + rho * (V[i - 1, :] - V[i, :]), torch.zeros(TASK_num))

  # Compute ADMM residuals and update rho correspondingly
  s = rho * torch.sqrt(torch.sum(torch.sum(torch.square(U_old - U)))) + rho * torch.sqrt(
    torch.sum(torch.sum(torch.square(V_old - V))))
  r = torch.sqrt(torch.sum(torch.sum(torch.square(U - W)))) + torch.sqrt(torch.sum(torch.sum(torch.square(V - T))))
  if (r > 10 * s):
    rho = 2 * rho
    #   update inverse matrix for computation of V-update when rho changes
    f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
    f2inv = torch.linalg.inv(beta * L + rho * E)
  else:
    if (10 * r < s):
      rho = rho / 2
      #       update inverse matrix for computation of V-update when rho changes
      f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
      f2inv = torch.linalg.inv(beta * L + rho * E)

  self.T = T
  self.W = -W

  adi_toc = time.perf_counter()
  time_taken = adi_toc-adi_tic
  adi_list.append(adi)
  adi_time_list.append(time_taken)
  r_list.append(r.item())
  s_list.append(s.item())
  rho_list.append(rho)
  if pred_too == True:
      # [mze, mae] = self.predict(X_train, Y_train, [T, -W, self.fc1.weight.data, self.fc1.bias.data])
      [mze, mae] = self.predict(X_train, Y_train)
      mze_list.append(mze)
      mae_list.append(mae)
      print('ADMM iteration: {}, r-residual: {}, s-residual: {}, rho: {}, mze: {}, mae: {}, time taken {}'.format(adi, r, s, rho,mze, mae, time_taken))
  else:
      print('ADMM iteration: {}, r-residual: {}, s-residual: {}, rho: {}, time taken {}'.format(adi, r, s, rho, time_taken))


  # Check for stop criteria
  if (r<1e-2 and s<1e-2):
      break

# Saving Results
# dictionary of lists
result_dict = {'iteration': adi_list, 'r-residual': r_list, 's_residual': s_list, 'rho': rho_list, 'mze': mze_list, 'mae': mae_list, 'time': adi_time_list}

result_df = pd.DataFrame(result_dict)

# saving the dataframe
result_df.to_csv(config.training_progress_log, index=False)
# The final learned model parameter set
# model_param = torch.cat((T, -W), 0)
# if pred_too==True:
#     [mze, mae] =self.predict(X_train, Y_train, [T, -W, self.fc1.weight.data, self.fc1.bias.data])
B = [T, -W, self.fc1.weight.data, self.fc1.bias.data]