import configure as config
import torch
import numpy as np
import torch.nn.functional as F
import proximal_gradient.proximalGradient as pg
from sklearn import metrics
import pandas as pd
import time
if torch.cuda.is_available():
    device = torch.device("cuda:0")  # you can continue going on here, like cuda:1 cuda:2....etc.
    print("Running on the GPU")
    print("Number of GPU {}".format(torch.cuda.device_count()))
    print("GPU type {}".format(torch.cuda.get_device_name(0)))
    print('Memory Usage:')
    print('Allocated:', round(torch.cuda.memory_allocated(0) / 1024 ** 3, 1), 'GB')
    print('Cached:   ', round(torch.cuda.memory_cached(0) / 1024 ** 3, 1), 'GB')
    torch.backends.cudnn.benchmark = False
    # torch.cuda.memory_summary(device=None, abbreviated=False)
    # print(torch.backends.cudnn.version())
else:
    device = torch.device("cpu")
    print("Running on the CPU")

class Model:
  def __init__(self, input_dim, hidden_dim):
    self.input_dim = input_dim
    self.hidden_dim = hidden_dim
    self.fc1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
    self.logsig = torch.nn.LogSigmoid()

  def fit(self, X_train,Y_train,adj_data,lr,alpha,beta, pred_too=True):

    adi_list = []
    adi_time_list = []
    r_list = []
    s_list = []
    rho_list = []
    mze_list = []
    mae_list = []

    values = Y_train.unique()
    k = values.shape[0]
    TRAIN_size = Y_train.shape[1]
    TASK_num = Y_train.shape[0]
    BIG = float('inf')
    SMALL = float('-inf')
    # d=demension of feature vector
    if config.using_mlp:
        d = self.hidden_dim
    else:
        d = self.input_dim

    R = torch.zeros((TASK_num, TASK_num))
    for i in range(TASK_num):
      nb = sum(adj_data[:, i] == 1)
      if nb > 0:
        R[:, i] = -torch.from_numpy(adj_data[:, i] / nb)
        R[i, i] = 1
    L = torch.matmul(R, np.transpose(R))
    E = torch.eye((TASK_num))
    # initialize parameters for training data for each task(size= d*TASK_num)
    W = torch.nn.Parameter(torch.empty(d, TASK_num).normal_(mean=0, std=0.1))
    U = W
    Y1 = torch.zeros(W.shape)
    # initialize threshold size : (k-1)*TASK_num
    pi = torch.nn.Parameter(torch.ones(k - 1, 1) * 1 / k)
    # assign each class with same probability
    cum_pi = torch.cumsum(pi, dim=0)  # Need to check here
    T = torch.log(cum_pi / (1 - cum_pi))
    T = T.repeat(1, TASK_num)
    Y2 = torch.zeros(T.shape)
    V = T
    Y3 = torch.zeros(k - 2, T.shape[1])
    # initialize learning rate lambda
    lambda_w = lr
    lambda_t = lr
    # admm param
    rho = 1

    # set max number of iterations for GD on W,T  update (can be shorter if meet stop critira)
    Max_iteration = config.max_iteration
    f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
    f2inv = torch.linalg.inv(beta * L + rho * E)

    # outer loop (W{Mitor W+h(x)}, U, V, Y, )
    for adi in range(config.adi_range):

      adi_tic = time.perf_counter()
      L_old = float('inf') # Previous loss
      I = torch.zeros(Max_iteration)
      L_train = torch.zeros(Max_iteration)

      # Update W,T via gradient decent
      for t in range(Max_iteration):
        # cross tasks overall loss
        loss = 0
        GW = torch.zeros((d, TASK_num))
        GT = torch.zeros((k - 1, TASK_num))

        for i in range(TASK_num):
                for j in range(TRAIN_size):
                    # calculate what is the model predict is
                    if config.using_mlp:
                        X_hidden = F.relu(self.fc1(X_train[i,j,:]))
                    else:
                        X_hidden = X_train[i,j,:]
                    if Y_train[i,j]==k:
                        sig1=1
                        sig2= self.logsig(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))
                        dif=SMALL
                    elif Y_train[i,j]==1:
                        sig1= self.logsig(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))
                        sig2=0
                        dif=SMALL
                    else:
                        sig1= self.logsig(T[int(Y_train[i,j])-1,i] - torch.matmul(X_hidden,W[:,i]))
                        sig2= self.logsig(T[int(Y_train[i,j])-2,i] - torch.matmul(X_hidden,W[:,i]))
                        dif= T[int(Y_train[i,j])-2,i]-T[int(Y_train[i,j])-1,i]
                    # loss
                    l_cum=-torch.log(sig1-sig2)

                    if(l_cum==float('inf')):
                        print("error: inf loss, please decrease learning rate!")
                    loss=loss+l_cum
                    if config.using_mlp:
                        l_cum.backward(retain_graph=True)
                    else:
                        pass
                    # we want to minimize p_cum w.r.t W and T
                    # Gradient Decent
                    gradient_w = X_hidden*(1-sig1-sig2)
                    GW[:,i]=GW[:,i]+gradient_w
                    gradient_t=torch.zeros(k-1)
                    # Form canonical vector e_yi and e_yi-1
                    if Y_train[i,j]==k:
                        gradient_t[int(Y_train[i,j])-2]=sig2
                    elif Y_train[i,j]==1:
                        gradient_t[int(Y_train[i,j])-1]=sig1-1
                    else:
                        gradient_t[int(Y_train[i,j])-1]=sig1-1+1/(1-torch.exp(-dif))
                        gradient_t[int(Y_train[i,j])-2]=sig2-1+1/(1-torch.exp(dif))
                    GT[:,i]=GT[:,i]+gradient_t

        GW = 1 / TRAIN_size * 1 / TASK_num * GW + Y1 + rho * (W - U)
        GT = 1 / TRAIN_size * 1 / TASK_num * GT + Y2 + rho * (T - V)
        # update parameters
        W = W - lambda_w * GW
        T = T - lambda_t * GT
        I[t] = t
        L_train[t] = 1 / TRAIN_size * 1 / TASK_num * loss + torch.sum(torch.sum(Y1 * (W - U))) + (rho / 2.) * torch.sum(
          torch.sum(torch.square((W - U)))) + torch.sum(torch.sum(Y2 * (T - V))) + (rho / 2) * torch.sum(
          torch.sum(torch.square(T - V)))

        if L_old-L_train[t]<1e-2:
            break
        L_old = L_train[t]

      # Update U
      U_old = U
      U = W + 1 / rho * Y1
      pg.l21(U, reg=alpha / rho)

      # Update V
      V_old = V
      V[1, :] = 1 / rho * Y2[1, :] + T[1, :]
      for i in range(1, k - 1):  # Not sure about the range starting point
        f1 = torch.matmul(
          (torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * (T[i, :] + V[i - 1, :]) + Y3[i - 1, :]), f1inv)
        f2 = torch.matmul((torch.matmul(beta * V[i - 1, :], L) + Y2[i, :] + rho * T[i, :] + Y3[i - 1, :]), f2inv)
        V[i, f1 <= V[i - 1, :]] = f1[f1 <= V[i - 1, :]]
        V[i, f2 > V[i - 1, :]] = f2[f2 > V[i - 1, :]]
      # Update Y
      Y1 = Y1 + rho * (W - U)
      Y2 = Y2 + rho * (T - V)
      for i in range(1, k - 1):  # Not sure about the range starting point
        Y3[i - 1, :] = torch.maximum(Y3[i - 1, :] + rho * (V[i - 1, :] - V[i, :]), torch.zeros(TASK_num))

      # Compute ADMM residuals and update rho correspondingly
      s = rho * torch.sqrt(torch.sum(torch.sum(torch.square(U_old - U)))) + rho * torch.sqrt(
        torch.sum(torch.sum(torch.square(V_old - V))))
      r = torch.sqrt(torch.sum(torch.sum(torch.square(U - W)))) + torch.sqrt(torch.sum(torch.sum(torch.square(V - T))))
      if (r > 10 * s):
        rho = 2 * rho
        #   update inverse matrix for computation of V-update when rho changes
        f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
        f2inv = torch.linalg.inv(beta * L + rho * E)
      else:
        if (10 * r < s):
          rho = rho / 2
          #       update inverse matrix for computation of V-update when rho changes
          f1inv = torch.linalg.inv(beta * L + 2 * rho * E)
          f2inv = torch.linalg.inv(beta * L + rho * E)

      self.T = T
      self.W = -W

      adi_toc = time.perf_counter()
      time_taken = adi_toc-adi_tic
      adi_list.append(adi)
      adi_time_list.append(time_taken)
      r_list.append(r.item())
      s_list.append(s.item())
      rho_list.append(rho)
      if pred_too == True:
          # [mze, mae] = self.predict(X_train, Y_train, [T, -W, self.fc1.weight.data, self.fc1.bias.data])
          [mze, mae] = self.predict(X_train, Y_train)
          mze_list.append(mze)
          mae_list.append(mae)
          print('ADMM iteration: {}, r-residual: {}, s-residual: {}, rho: {}, mze: {}, mae: {}, time taken {}'.format(adi, r, s, rho,mze, mae, time_taken))
      else:
          print('ADMM iteration: {}, r-residual: {}, s-residual: {}, rho: {}, time taken {}'.format(adi, r, s, rho, time_taken))


      # Check for stop criteria
      if (r<1e-2 and s<1e-2):
          break

    # Saving Results
    # dictionary of lists
    result_dict = {'iteration': adi_list, 'r-residual': r_list, 's_residual': s_list, 'rho': rho_list, 'mze': mze_list, 'mae': mae_list, 'time': adi_time_list}

    result_df = pd.DataFrame(result_dict)

    # saving the dataframe
    result_df.to_csv(config.training_progress_log, index=False)
    # The final learned model parameter set
    # model_param = torch.cat((T, -W), 0)
    # if pred_too==True:
    #     [mze, mae] =self.predict(X_train, Y_train, [T, -W, self.fc1.weight.data, self.fc1.bias.data])
    return [T, -W, self.fc1.weight.data, self.fc1.bias.data]

  # def predict(self, X_test, Y_test, trained_param):
  def predict(self, X_test, Y_test):

      # [T, W, self.fc1.weight.data, self.fc1.bias.data] = trained_param
      TASK_num = Y_test.shape[0]
      for i in range(TASK_num):
          if config.using_mlp:
              X_hidden = F.relu(self.fc1(X_test[i, :, :]))
          else:
              X_hidden = X_test[i, :, :]

          unique_theta = torch.sort(torch.unique(self.T[:, i]))
          # unique_theta.values[-1]=torch.inf
          out = torch.matmul(X_hidden, self.W[:, i])
          tmp = out[:, None].repeat(1, unique_theta.values.shape[0])
          pred = torch.argmax((tmp < unique_theta.values).long(), dim=1)
          if i == 0:
              Y_pred = pred.unsqueeze(0)
          else:
              Y_pred = torch.cat((Y_pred, pred.unsqueeze(0)), 0)

      zero_one_sum = 0
      for i in range(TASK_num):
          zero_one_task = metrics.zero_one_loss(Y_test[0, :], Y_pred[0, :])
          zero_one_sum += zero_one_task
      mze = zero_one_sum / TASK_num
      mae = ((Y_pred != Y_test).long().sum()/Y_test.ravel().shape[0]).item()

      return [mze, mae]

